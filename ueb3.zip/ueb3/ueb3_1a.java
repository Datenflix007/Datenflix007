public class ueb3_1a {
	
	
	
	//Veranstaltungstypen
	class Vorlesung
	{
		
	}
	
	class Uebungen
	{
		
	}
	
	class Praktika
	{ 
		
	}
	
	//adresse
	class Adresse{
		private String strasse;
		private String plz;
		private String ort;
				
		public Adresse(String strasse, String plz, String ort)
		{
			this.strasse = strasse;
			this.plz = plz;
			this.ort = ort;
		}
		
		public String getPlz()
		{
			return this.plz;
		}
		public String getStrasse()
		{
			return this.strasse;
		}
		public String getOrt()
		{
			return this.ort;
		}
	}
	
	//Räume
	class Hoersaal{
		private int plaetze;
		private Adresse adresse;
		
		private Vorlesung[] vorlesungen;
		private int vl_counter = 0;
		
		Hoersaal(int plz, Adresse adr, Vorlesung vl)
		{
			this.plaetze = plz;
			this.adresse = adr;
			this.vorlesungen[vl_counter++] = vl;
		}
		public int getPlaetze()
		{
			return this.plaetze;			
		}
		public Adresse getAdresse()
		{
			return this.adresse;
		}
		public Vorlesung getVorlesungen()
		{
			return getVorlesungen();
		}
	}
	
	class Seminarraum{		
		private int plaetze;
		private Adresse adresse;
		
		private Uebungen[] uebungen;
		private int ueb_counter = 0;
		
		Seminarraum(int plz, Adresse adr, Uebungen ueb)
		{
			this.plaetze = plz;
			this.adresse = adr;
			this.uebungen[ueb_counter++] = ueb;
		}
		public int getPlaetze()
		{
			return this.plaetze;			
		}
		public Adresse getAdresse()
		{
			return this.adresse;
		}
		public Uebungen getUebungen()
		{
			return uebungen[ueb_counter];
		}
	}
	
	class Labor{		
		private int plaetze;
		private Adresse adresse;
		
		private Praktika[] praktikum;
		private int prk_counter = 0;
		
		Labor(int plz, Adresse adr, Praktika prk)
		{
			this.plaetze = plz;
			this.adresse = adr;
			this.praktikum[prk_counter++] = prk;
		}
		public int getPlaetze()
		{
			return this.plaetze;			
		}
		public Adresse getAdresse()
		{
			return this.adresse;
		}
		public Praktika getPraktika()
		{
			return praktikum[prk_counter];
		}
	}
	
	Hoersaal hoersaal1 = new Hoersaal(300, new Adresse("Kuglerstrasse", "06618", "Naumburg"), new Vorlesung());
	Hoersaal hoersaal2 = new Hoersaal(250, new Adresse("abc","def","ghi"), new Vorlesung());
	Seminarraum SR112 = new Seminarraum(20, new Adresse("Jägerstraße","06618", "Naumburg"), new Uebungen());
	
	
	public static void main(String[] args) {
		
	
	}
}	