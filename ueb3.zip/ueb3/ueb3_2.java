
class ERROR{
	private static String err_01 = "AIRPORT_ERROR_001: Flightnumber already forgiven!";
	private static String err_02 = "AIRPORT ERROR_002: Maximal Flightnumber allready forgiven!";
	
	public static String getErr01() {
		return err_01;
	}
	public static String getErr02() {
		return err_02;
	}
	
}

class Flight {
	int flightNumber; // Flugnummer
	String location; // Abflugs-/Zielort
	String gate; // Gate
	String time; // Abflugs-/Ankunftszeit
	public int inOut; // ein- oder abgehender Flug
			//true->abgehende Flüge, false-> eingehende Flüge
	Flight(int FN, String loc, String gate, String time, int IO)
	{
		this.flightNumber = FN;
		this.location = loc;
		this.gate = gate;
		this.time = time;
		this.inOut = IO;
	}



}

class Airport{
	static int maxFlights;
	
	private Flight [] flightOverview;
	private int flight_counter;
	
	
	Airport(int maxFlights)
	{
		Airport.maxFlights = maxFlights;
		this.flightOverview = new Flight[maxFlights];		
		this.flight_counter = 0;
	}
	void addNewFligth(Flight flight)
	{ 
		if((this.flight_counter < this.flightOverview.length)&&(this.flight_counter > 0))
		{
			boolean alreadyExisting = false;
			for(int i=0; i<flight_counter; i++)
			{
				if(this.flightOverview[i].flightNumber == flight.flightNumber) {
					alreadyExisting = true;
				}
			}
			if(alreadyExisting == false) {
				flightOverview[flight_counter] = new Flight(flight.flightNumber, flight.location, flight.gate, flight.time, flight.inOut);
				this.flight_counter++;
			} else {
				System.out.println(ERROR.getErr01());
			}
		} 	
		else if((this.flight_counter < this.flightOverview.length)&&(this.flight_counter == 0))
		{
			
				flightOverview[flight_counter] = new Flight(flight.flightNumber, flight.location, flight.gate, flight.time, flight.inOut);
				this.flight_counter++;
			
		} 		
		else if(flight_counter+1 >= this.flightOverview.length){
			System.out.println(ERROR.getErr02());
		}
		
	}
	void removeFlight(int flightNumber)
	{
		//Index der flightNumber ermitteln
		int idx, i = 0;
		while((i<flightOverview.length) && (flightOverview[i].flightNumber != flightNumber))
		{
			i++;
		}
		idx = i;		 //zu löschender Index
		
		//nach links aufschieben
		for( i =idx; i<this.flightOverview.length-1; i++)
		{
			this.flightOverview[i] = this.flightOverview[i+1];
		}
		//für Überschreiben des letzen Elementes(Dopplung) sorgen
		this.flight_counter--;
		//this.flightOverview[this.flightOverview.length-1].flightNumber = 0;
	}
	
	void listDeparturesOnScreens()
	{
		for(int i = 0; i<this.flightOverview.length; i++)
		{
			 if((this.flightOverview[i].inOut == 1)&&(this.flightOverview[i] != null)) { 
				System.out.println(flightOverview[i].flightNumber+":\tAnkunft um \t"+flightOverview[i].time+"\t am Gate\t"+flightOverview[i].gate+"\tnach\t"+flightOverview[i].location);}
		} 
		if((this.flightOverview[flightOverview.length-1].inOut == 1)&&(this.flightOverview[flightOverview.length-1].flightNumber != this.flightOverview[flightOverview.length-2].flightNumber))
		{
			System.out.println(flightOverview[flightOverview.length-1].flightNumber+":\tAnkunft um \t"+flightOverview[flightOverview.length-1].time+"\t am Gate\t"+flightOverview[flightOverview.length-1].gate+"\tnach\t"+flightOverview[flightOverview.length-1].location);
		}
	}
	
	void listArrivalsOnScreen()
	{
		for(int i = 0; i<this.flightOverview.length-1; i++)
		{
			if((this.flightOverview[i].inOut == 0)&&(this.flightOverview[i] != null)) { System.out.println(flightOverview[i].flightNumber+":\tAbflug um \t"+flightOverview[i].time+"\t am Gate\t"+flightOverview[i].gate+"\tnach\t"+flightOverview[i].location);}
		}
		if((this.flightOverview[flightOverview.length-1].inOut == 0)&&(this.flightOverview[flightOverview.length-1].flightNumber != this.flightOverview[flightOverview.length-2].flightNumber))
		{
			System.out.println(flightOverview[flightOverview.length-1].flightNumber+":\tAbflug um \t"+flightOverview[flightOverview.length-1].time+"\t am Gate\t"+flightOverview[flightOverview.length-1].gate+"\tnach\t"+flightOverview[flightOverview.length-1].location);
		}
	}
	
}



public class ueb3_2 {

	public static void main(String[] args) {
		Airport airport = new Airport(7);		
		airport.addNewFligth(new Flight(12345, "BER5", "London", "12:13:34", 1));
		airport.addNewFligth(new Flight(23445, "BER1", "New York", "23:56:11", 0));
		airport.addNewFligth(new Flight(3456, "BER2", "Shanghei", "13:13:13", 0));
		airport.addNewFligth(new Flight(45678, "BER3", "Tokjo", "13:13:13", 1));
		airport.addNewFligth(new Flight(45908, "BER3", "Tokjo", "13:13:13", 1));
		airport.addNewFligth(new Flight(56789, "BER3", "Berlin", "13:13:13", 1));
		airport.addNewFligth(new Flight(56789, "BER5", "Kiew", "13:13:13", 0));
		airport.addNewFligth(new Flight(67, "BER5", "Kiew", "13:13:13", 0));
		airport.addNewFligth(new Flight(89, "BER3", "München", "13:13:13", 1));
		
		
		System.out.println("\nLosfliegende Fliege von diesem Flughafen:");
		airport.listDeparturesOnScreens();
		System.out.println("\nEingehnde Flüge von diesem Flughafen:");
		airport.listArrivalsOnScreen();
		
		airport.removeFlight(3456);
		
		System.out.println("\nLosfliegende Fliege von diesem Flughafen:");
		airport.listDeparturesOnScreens();
		System.out.println("\nEingehnde Flüge von diesem Flughafen:");
		airport.listArrivalsOnScreen();
		
		airport.addNewFligth(new Flight(65421, "BER3", "Moskau", "13:13:13", 0));
		System.out.println("\nLosfliegende Fliege von diesem Flughafen:");
		airport.listDeparturesOnScreens();
		System.out.println("\nEingehnde Flüge von diesem Flughafen:");
		airport.listArrivalsOnScreen();
	}

}
